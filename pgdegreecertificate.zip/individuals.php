<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/individual.jpg);">
            <div class="container">
                <div class="title-text">
                    <h1>Individuals</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index.php">Individuals &nbsp;/</a>
                        </li>
                        <li>Individuals</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/individual.jpg" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Individuals</h2>
                            <p>Every single one of us has a dream, one for ourselves and one for the society in which we live.</p>

                            <p>We can "make it work" if we work together. The MMK Foundation assists people like you who have the ability and sensitivity to give wisely and generously to the underprivileged. We make charitable giving simple, flexible, and tax-efficient. We understand your situation and will work with you to make the most of your donation.
                            </p>

                         
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php')?>