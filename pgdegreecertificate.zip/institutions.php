<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/institutions.jpg);">
            <div class="container">
                <div class="title-text">
                    <h1>Institutions</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index.php">Home &nbsp;/</a>
                        </li>
                        <li>Institutions</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/institutions.jpg" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Institutions</h2>
                            <p>The MMK Foundation forms alliances and networks with national and international development institutions to link their domain expertise, resources, and strengths with its own grassroots development initiatives.</p>

                            <p>Along with the expansion and strengthening of existing programmes, Alliances at MMK Foundation focuses on bringing innovations to its programmes through collaboration with global development actors.
                            </p>

                            

                         
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php')?>