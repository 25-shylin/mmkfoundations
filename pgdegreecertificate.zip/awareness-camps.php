<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/awareness-camps.jpg);">
            <div class="container">
                <div class="title-text">
                    <h1>Awareness Camps</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index.php">Home &nbsp;/</a>
                        </li>
                        <li>Awareness Camps</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/awareness-camps.jpg" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Awareness Camps</h2>
                            <p>It is critical to educate and raise public knowledge in order to secure the growth and development of society. People should be aware of their legal rights, orders, health, and educational opportunities, among other things. Corporates are eager to organise social awareness camps in order to comply with CSR regulations. These awareness camps necessitate the participation of experts from many sectors who will share their knowledge and experience with the general public.</p>
                            <p>
                            At the MMK Foundation, we help cooperate organize social awareness camps in areas such as health, education, hygiene, and legal rights. The MMK Foundation ensures that these awareness programmes are held in villages, impoverished schools, and backward areas, among other places. Our operations staff makes certain that these camps are well-planned and properly implemented.
                            </p>
                            <p>The MMK Foundation thinks that these social awareness camps may assist society in educating its members, and that this will have a significant impact on the country's future.</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php')?>