<?php include('include/header.php')?>

        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/education.png);">
            <div class="container">
                <div class="title-text">
                    <h1>Education</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="education.html">Education &nbsp;/</a>
                        </li>
                        <li>Education</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/edu.png" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Education</h2>
                            <p>Education is a state-level initiative of the MMK Foundation, a non-profit organisation dedicated to providing basic education and healthcare to impoverished children. The MMK Foundation, a non-profit organisation dedicated
                                to improving the education of underprivileged children, thinks that there is no better place to begin than in the halls of education, whether the issue is healthcare, poverty, population control, unemployment, or human
                                rights.
                            </p>
                            <p>Education is both the means and the end to a better life; it is the means because it allows an individual to earn a living, and it is the end because it increases one&#39;s awareness of a variety of issues ranging from healthcare
                                to appropriate social behaviour to understanding one&#39;s rights, allowing one to evolve as a better citizen.</p>
                                <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left; background: #fcac4b; padding: 30px 127px; max-width: 49%; color: #fff;">Aim</div>
                           <div class="col-lg-3" style="float: right; background: #5ad05e;padding: 30px 86px; max-width: 49%; color: #fff;">Beneficiary</div>
                        </div>
                        <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left;background: #ff636c;padding: 30px 99px; margin-top: 5px; max-width: 50%; color: #fff;">Achievement</div>
                           <div class="col-lg-3" style="float: right; background: #1c62fe;padding: 30px 98px; margin-top: 5px; max-width: 49%; color: #fff;">Doner</div>
                        </div>
                        </div>
                        
                    </div>
                    </div>
                    
                </div>
            </div>
        </section>

  <?php include('include/footer.php')?>