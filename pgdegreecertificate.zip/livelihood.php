<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/live.png);">
            <div class="container">
                <div class="title-text">
                    <h1>Livelihood</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="livelihood.html">Livelihood &nbsp;/</a>
                        </li>
                        <li>Livelihood</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/live.png" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Livelihood</h2>
                            <p>Over one-third of India&#39;s population is under the age of 30, making up a significant portion of the country&#39;s labour force. According to Financial Express estimates, just 14% of new graduates graduating from colleges
                                are employable, while the remainder are labelled unemployable.
                            </p>

                            <p>This is not due to a lack of theoretical knowledge on their part. Instead, it&#39;s a lack of the necessary abilities and attitude. As a result, there is growing anxiety among the country&#39;s top businesses about a shortage
                                of ready-to-deliver staff. Furthermore, the macro perspective</p>

                            <p>emphasises that it is critical for the underprivileged youth&#39;s energy to be channelled appropriately and in the right direction to aid economic progress and nation building, avoiding their contribution to family problems,
                                societal stress, and national sorrow.</p>

                            <p> This national-level initiative, through its livelihood programmes, teaches English proficiency, basic computer education, and soft skills to disadvantaged and underprivileged youngsters in order to improve their career prospects
                                in the fast-growing retail, hospitality, and BPO sectors.</p>
                                <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left; background: #fcac4b; padding: 30px 127px; max-width: 49%; color: #fff;">Aim</div>
                           <div class="col-lg-3" style="float: right; background: #5ad05e;padding: 30px 86px; max-width: 49%; color: #fff;">Beneficiary</div>
                        </div>
                        <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left;background: #ff636c;padding: 30px 99px; margin-top: 5px; max-width: 50%; color: #fff;">Achievement</div>
                           <div class="col-lg-3" style="float: right; background: #1c62fe;padding: 30px 98px; margin-top: 5px; max-width: 49%; color: #fff;">Doner</div>
                        </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

  <?php include('include/footer.php')?>