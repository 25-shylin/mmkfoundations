<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/women.png);">
            <div class="container">
                <div class="title-text">
                    <h1>women-Empowerment</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index-2.html">women-Empowerment /</a>
                        </li>
                        <li>women-Empowerment</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/wom.png" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Women Empowerment</h2>
                            <p>Various research, as well as our own experience, have proven that working toward women&#39;s empowerment benefits the entire society. However, in India, far from empowering women, the majority are denied even fundamental rights
                                such as health, girls&#39; education for women&#39;s empowerment, job, and a decent social status.</p>

                            <p>According to a recent UNDP Human Development Report, India has a dangerously skewed sex ratio, with female infanticide and sex-selective abortions being the primary causes.</p>

                            <p>Increase awareness of corporate innovations that accelerate women&#39;s empowerment and have a real impact on women&#39;s, families&#39;, and communities&#39; quality of life; child marriage is still practised in many parts
                                of India. This leads to early pregnancies, which endangers not only the lives and health of young women, but also their ability to raise a family. The MMK Foundation wants women and girls to be able to make their own decisions
                                and to understand that they do not object to being told who and when they should marry. We intend to put a stop to this type of discrimination by educating individuals about family planning options.</p>
                                <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left; background: #fcac4b; padding: 30px 127px; max-width: 49%; color: #fff;">Aim</div>
                           <div class="col-lg-3" style="float: right; background: #5ad05e;padding: 30px 86px; max-width: 49%; color: #fff;">Beneficiary</div>
                        </div>
                        <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left;background: #ff636c;padding: 30px 99px; margin-top: 5px; max-width: 50%; color: #fff;">Achievement</div>
                           <div class="col-lg-3" style="float: right; background: #1c62fe;padding: 30px 98px; margin-top: 5px; max-width: 49%; color: #fff;">Doner</div>
                        </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

<?php include('include/footer.php')?>