<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/abo.png);">
            <div class="container">
                <div class="title-text">
                    <h1>about us</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index-2.html">home &nbsp;/</a>
                        </li>
                        <li>about us</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/service-one.jpg" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>About Us</h2>
                            <p>
                                Every year, the MMK Foundation, an Indian non-profit organisation dedicated to social development, directly benefits over 1000 children and their families. We have active welfare programmes in over 20 distant villages and urban slums in Tamil Nadu, India,
                                focusing on education, healthcare, livelihood, and women&#39;s empowerment. </p>

                            <p>Education lays the foundation for a better life. It is the most effective catalyst for societal change. A youngster, on the other hand, cannot be educated in solitude. Only a strong family, particularly the mother, will agree
                                to educate their child. We believe in a lifelong strategy rather than focusing on just one period of a person&#39;s life.</p>

                            <p>Education allows a person to earn a living while simultaneously increasing their awareness of a variety of concerns. The MMK Foundation works to educate, empower, and grow better citizens in a variety of areas, including healthcare,
                                good social behaviour, and recognising one&#39;s rights.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php include('include/footer.php')?>