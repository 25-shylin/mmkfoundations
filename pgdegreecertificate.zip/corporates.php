<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/corporates.jpg);">
            <div class="container">
                <div class="title-text">
                    <h1>Corporates</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index.php">Home &nbsp;/</a>
                        </li>
                        <li>Corporates</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/corporates.jpg" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Corporates</h2>
                            <p>MMK Foundation is a small non-profit organization with a big heart dedicated to bringing about a paradigm shift in the NGO space through selfless and sustained service to restore the dignity of socially backward communities.</p>

                            <p>A corporate that supports socially responsible initiatives would not only resonate with customers and employees, but would also make a difference in the real world. If you want to keep your CSR initiatives thriving, you will need drive and passion at the leadership level. You would need to partner with the right NGO to effectively reach out to the greatest number of underprivileged people and ensure that your donations positively transform their lives. You will be pleased to know that the MMK Foundation has been at the forefront of "Including the Excluded in the Growth Trajectory." "Every rupee we receive will be spent wisely."
                            </p>

                            <p>"We guarantee it." Rural health and hygiene, education, environmental sustainability, rural employment, and women's empowerment are just a few of the flagship projects we're working on.
                            </p>

                         
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php')?>