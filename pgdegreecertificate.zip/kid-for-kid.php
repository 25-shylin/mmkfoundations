<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/kid.png);">
            <div class="container">
                <div class="title-text">
                    <h1>Kid For Kid
                    </h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="kid-for-kid.html">Kid For Kid
                                &nbsp;/</a>
                        </li>
                        <li>Kid For Kid
                        </li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/kd.png" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Kid for Kid</h2>
                        </div>
                        <p>Children are a country&#39;s future. They are the most effective change agents, whether in the family or in the community in which they live. It is therefore critical to assist children, to catch them when they are young and to
                            instil in them feelings of empathy and conscience so that they grow up to be responsible individuals. Recognizing this need, the MMK Foundation launched the Kid for Kid (KFK) programme in 2022. Sensitization of privileged children
                            and their parents to existing inequalities around them is a key goal of KFK.
                        </p>
                        <p>Privileged children are made aware of the deprivation and pain endured by underprivileged children. KFK aims to instil a sense of conscience and a value system in children so that they grow up to be responsible citizens and change
                            agents. The KFK programme tries to make them count their blessings and understand the plight of those who are less fortunate before their minds are set with age. They automatically turn their thoughts to positivity and develop
                            the right outlook once they begin to recognise the value of the advantages they are born with. This eventually helps them develop into not only successful but also responsible adults. They grow up to be significant change agents
                            who positively contribute to society.
                            <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left; background: #fcac4b; padding: 30px 127px; max-width: 49%; color: #fff;">Aim</div>
                           <div class="col-lg-3" style="float: right; background: #5ad05e;padding: 30px 86px; max-width: 49%; color: #fff;">Beneficiary</div>
                        </div>
                        <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left;background: #ff636c;padding: 30px 99px; margin-top: 5px; max-width: 50%; color: #fff;">Achievement</div>
                           <div class="col-lg-3" style="float: right; background: #1c62fe;padding: 30px 98px; margin-top: 5px; max-width: 49%; color: #fff;">Doner</div>
                        </div>
                        </p>
                    </div>
                </div>
            </div>
    </div>
    </section>

   <?php include('include/footer.php')?>