<?php include('include/header.php')?>

        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/covid.png);">
            <div class="container">
                <div class="title-text">
                    <h1>covid-19</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index-2.html">home &nbsp;/</a>
                        </li>
                        <li>covid-19</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->


        <section class="section">
            <div class="container service-box">
                <div class="row">

                    <div class="col-lg-12">
                        <div class="contents">
                            <div class="section-title">
                                <h3>COVID-19
                                </h3>
                            </div>

                            <ul class="content-list">
                                <li>
                                    <i class="far fa-check-circle"></i>To provide food to those in need, particularly the poor, the elderly, children, migrant workers, the homeless, and people without a job during a lockdown.</li>
                                <li>
                                    <i class="far fa-check-circle"></i>To assist homeless people in reaching government / private shelter homes / food banks</li>
                                <li>
                                    <i class="far fa-check-circle"></i>To provide immediate assistance to people who are experiencing a medical emergency and to assist them in reaching a nearby medical centre or hospital.</li>

                                <li>
                                    <i class="far fa-check-circle"></i>To assist migrant workers by informing them about government-run trains and assisting them in booking online train tickets.</li>
                                <li>
                                    <li>
                                        <i class="far fa-check-circle"></i>To educate the public, using creative means, about maintaining proper physical distances and taking all other precautions, particularly in places where people congregate frequently,
                                        such as banks, ATMs, market places, food camps, night shelters, outside factories, and so on.</li>
                                    <li>
                                        <li>
                                            <i class="far fa-check-circle"></i>To compile a list of patients who require regular life-saving medical care (dialysis, chemotherapy, thalassemia, heart patients, and other such related medical needs) and to
                                            find out the status of their health and requirements on a regular basis, as well as to assist them in reaching medical centres if necessary.</li>
                                        <li>
                                            <i class="far fa-check-circle"></i>To compile a list of patients who have been advised to undergo surgeries or urgent medical procedures and cannot postpone the treatment any longer, and to counsel them with
                                            the assistance of volunteers, as well as to obtain the necessary permission and resources to continue the treatment.</li>
                                        <li>
                                            <li>
                                                <i class="far fa-check-circle"></i>To compile a list of all Central / State Government helpline numbers, as well as a list of nearby medical centres, pharmacy stores, and official help numbers, and to communicate
                                                them to the public through newspaper and cable TV advertisements.</li>
                                            <li>

                                                <li>
                                                    <i class="far fa-check-circle"></i>To compile a list of medical professionals / workers in the District (or within 10 kilometres) who can be contacted for medical assistance / counselling.
                                                </li>
                                                <li>

                                                    <li>
                                                        <i class="far fa-check-circle"></i>To make people aware of the Arogya Setu App and assist them in downloading and using its features.
                                                    </li>
                                                    <li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php include('include/footer.php')?>