<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/school.jpg);">
            <div class="container">
                <div class="title-text">
                    <h1>Schools</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="index.php">Home &nbsp;/</a>
                        </li>
                        <li>Schools</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/school.jpg" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Schools</h2>
                            <p>The MMK Foundation visits schools and holds engaging sessions for young minds.</p>
                         
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php')?>