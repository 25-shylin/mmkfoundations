<?php 
session_start();
 if (!isset($_SESSION['admin_name'])) {
    header("location: index.php");
 }
 else {
    include("includes/database.php");
    include('includes/header.php');
    include('includes/sidebar.php');
    $page_user = $_SESSION['username'];
    $selectvolunteerquery = "select * from volunteers where volunteersno = '$page_user'";
      $runvolunteerQuery = mysqli_query($con,$selectvolunteerquery);
       $serialNum = 1;
       while ($rowvolunteerquery = mysqli_fetch_array($runvolunteerQuery)) {
        $serialNumber = $serialNum++;
        $volunteersid = $rowvolunteerquery['volunteersid'];
        $volunteersno = $rowvolunteerquery['volunteersno'];
        $firstname = $rowvolunteerquery['firstname'];
        $middlename = $rowvolunteerquery['middlename'];
        $lastname = $rowvolunteerquery['lastname'];
        $dob = $rowvolunteerquery['dob'];
        $gender = $rowvolunteerquery['gender'];
        $nationality = $rowvolunteerquery['nationality'];
        $address= $rowvolunteerquery['address'];
        $city = $rowvolunteerquery['city'];
        $othercity = $rowvolunteerquery['othercity'];
        $state = $rowvolunteerquery['state'];
        $otherstate = $rowvolunteerquery['otherstate'];
        $country = $rowvolunteerquery['country'];
        $pincode = $rowvolunteerquery['pincode'];
        $localguardian = $rowvolunteerquery['localguardian'];
        $localcity = $rowvolunteerquery['localcity'];
        $localothercity = $rowvolunteerquery['localothercity'];
        $localstate = $rowvolunteerquery['localstate'];
        $localotherstate = $rowvolunteerquery['localotherstate'];
        $localcountry = $rowvolunteerquery['localcountry'];
        $localpincode = $rowvolunteerquery['localpincode'];
        $phoneresid = $rowvolunteerquery['phoneresid'];
        $mobileno = $rowvolunteerquery['mobileno'];
        $email = $rowvolunteerquery['email'];
        $facebook = $rowvolunteerquery['facebook'];
        $degree = $rowvolunteerquery['degree'];
        $university = $rowvolunteerquery['university'];
        $workyears = $rowvolunteerquery['workyears'];
        $industry = $rowvolunteerquery['industry'];
        $profession = $rowvolunteerquery['profession'];
        $english = $rowvolunteerquery['english'];
        $otherlanguage = $rowvolunteerquery['otherlanguage'];
        $workknowledge = $rowvolunteerquery['workknowledge'];
        $itskills = $rowvolunteerquery['itskills'];
        $programarea = $rowvolunteerquery['programarea'];
        $workarea = $rowvolunteerquery['workarea'];
        $relocation = $rowvolunteerquery['relocation'];
        $months = $rowvolunteerquery['months'];
        $days = $rowvolunteerquery['days'];
        $hours = $rowvolunteerquery['hours'];
        $password = $rowvolunteerquery['password'];
        $volunteerimg = $rowvolunteerquery['volunteerimg'];
        $creatdate = $rowvolunteerquery['creatdate'];
        $modifydate = $rowvolunteerquery['modifydate'];
        $status = $rowvolunteerquery['status'];
    ?>

    <!--==================================*
               Main Content Section
    *====================================-->
    <div class="main-content page-content">

        <!--==================================*
                   Main Section
        *====================================-->
        <div class="main-content-inner">
            <div class="row">
                <!-- Primary table -->
                <div class="col-12 mt-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Command Details</h4>
                            <div class="table-responsive datatable-primary">
                                <div class="col-md-12">
                                <div class="card-box">
                                  
                                    <form method="post" action="#" enctype="multipart/form-data">
                                         <div class="row">   
                                                <div class="col-md-3">
                                                </div>
                                                <div class="col-md-6">
                                                        <div class="form-group" hidden>
                                                            <label for="firstname">First Name</label>
                                                            <input type="text" class="form-control" id="firstname"  name="firstname">
                                                        </div>
                                                        <div class="form-group" hidden>
                                                            <label for="volunteersno">Volunteers No</label>
                                                            <input type="text" class="form-control" id="volunteersno"  name="volunteersno">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="commandtitle">Command Title</label>
                                                            <input type="text" class="form-control" id="commandtitle"  name="commandtitle">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="commanddate">Command Date</label>
                                                            <input type="date" class="form-control" id="commanddate"  name="commanddate">
                                                        </div>

                                                    
                                                        <div class="form-group">
                                                            <label for="newsdescription">Command Description</label>
                                                            
                                                            <textarea class="form-control" id="commanddescription" name="commanddescription"></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="newsphoto">Command Photo</label>
                                                            <input type="file" class="form-control" id="commandphoto" name="commandphoto">
                                                        </div>
                                                        <div class="form-group">
                                                            
                                                            <input type="submit" name="submit" class="btn btn-primary pull-right" value="Submit">
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                </div>
                                          </div>
                                        </div>

                                        
                                    </form>
                                </div>
                            </div><!-- end col -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Primary table -->
            </div>
            
        </div>
        <!--==================================*
                   End Main Section
        *====================================-->
    </div>
    <!--=================================*
           End Main Content Section
    *===================================-->

<?php include('includes/footer.php') ?>

<?php } } ?>
<?php 
      
     if (isset($_POST['submit'])) {
        
      $selectvolunteerquery = "select * from volunteers where volunteersno = '$page_user'";
      $runvolunteerQuery = mysqli_query($con,$selectvolunteerquery);
       $serialNum = 1;
       while ($rowvolunteerquery = mysqli_fetch_array($runvolunteerQuery)) {
        $serialNumber = $serialNum++;
        $volunteersid = $rowvolunteerquery['volunteersid'];
        $volunteersno = $rowvolunteerquery['volunteersno'];
        $firstname = $rowvolunteerquery['firstname'];
        $middlename = $rowvolunteerquery['middlename'];
        $lastname = $rowvolunteerquery['lastname'];
        $dob = $rowvolunteerquery['dob'];
        $gender = $rowvolunteerquery['gender'];
        $nationality = $rowvolunteerquery['nationality'];
        $address= $rowvolunteerquery['address'];
        $city = $rowvolunteerquery['city'];
        $othercity = $rowvolunteerquery['othercity'];
        $state = $rowvolunteerquery['state'];
        $otherstate = $rowvolunteerquery['otherstate'];
        $country = $rowvolunteerquery['country'];
        $pincode = $rowvolunteerquery['pincode'];
        $localguardian = $rowvolunteerquery['localguardian'];
        $localcity = $rowvolunteerquery['localcity'];
        $localothercity = $rowvolunteerquery['localothercity'];
        $localstate = $rowvolunteerquery['localstate'];
        $localotherstate = $rowvolunteerquery['localotherstate'];
        $localcountry = $rowvolunteerquery['localcountry'];
        $localpincode = $rowvolunteerquery['localpincode'];
        $phoneresid = $rowvolunteerquery['phoneresid'];
        $mobileno = $rowvolunteerquery['mobileno'];
        $email = $rowvolunteerquery['email'];
        $facebook = $rowvolunteerquery['facebook'];
        $degree = $rowvolunteerquery['degree'];
        $university = $rowvolunteerquery['university'];
        $workyears = $rowvolunteerquery['workyears'];
        $industry = $rowvolunteerquery['industry'];
        $profession = $rowvolunteerquery['profession'];
        $english = $rowvolunteerquery['english'];
        $otherlanguage = $rowvolunteerquery['otherlanguage'];
        $workknowledge = $rowvolunteerquery['workknowledge'];
        $itskills = $rowvolunteerquery['itskills'];
        $programarea = $rowvolunteerquery['programarea'];
        $workarea = $rowvolunteerquery['workarea'];
        $relocation = $rowvolunteerquery['relocation'];
        $months = $rowvolunteerquery['months'];
        $days = $rowvolunteerquery['days'];
        $hours = $rowvolunteerquery['hours'];
        $password = $rowvolunteerquery['password'];
        $volunteerimg = $rowvolunteerquery['volunteerimg'];
        $creatdate = $rowvolunteerquery['creatdate'];
        $modifydate = $rowvolunteerquery['modifydate'];
        $status = $rowvolunteerquery['status'];

        $commandtitle = $_POST['commandtitle'];
        $commanddate = $_POST['commanddate'];
        $commanddescription = $_POST['commanddescription'];
       
        //-----------------------------------------//
        
       $selectcommandquerycount = "select * from volunteerscommand";
       $runcount = mysqli_query($con, $selectcommandquerycount);
       $commandnumber = mysqli_num_rows($runcount)+1;

       $commandphoto_command = $_FILES['commandphoto'] ['name'];
       $commandphoto_tmp = $_FILES['commandphoto'] ['tmp_name'];

       $commandphoto = $commandnumber."_".$commandphoto_command;

        
        
      move_uploaded_file($commandphoto_tmp, "../commandphoto/$commandphoto");
      
      

       //-----------------------------------------//

      $commandquery = "insert into volunteerscommand(firstname, volunteersno, commandtitle, commanddate, commanddescription, commandphoto)values('$firstname', '".$volunteersno."', '$commandtitle', '$commanddate', '$commanddescription', '$commandphoto')";

       if ($commandtitle == '') {
        echo "<script>alert('Please Enter Command Title')</script>";
       }else
          {
          mysqli_query($con, $commandquery);
          echo "<script>alert('Your Command Details Added')</script>";
          echo "<script>window.open('command.php','_self')</script>";
          
         }
     
     }
}
 ?>