<?php include('include/header.php')?>
        <!--Page Title-->
        <section class="page-title text-center" style="background-image:url(images/background/health.png);">
            <div class="container">
                <div class="title-text">
                    <h1>Health</h1>
                    <ul class="title-menu clearfix">
                        <li>
                            <a href="health.html">Health &nbsp;/</a>
                        </li>
                        <li>Health</li>
                    </ul>
                </div>
            </div>
        </section>


        <!-- Our Story -->
        <section class="story">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img loading="lazy" src="images/services/hea.png" class="responsive" alt="story">
                    </div>
                    <div class="col-lg-6">
                        <div class="story-content">
                            <h2>Health</h2>
                            <p>Since independence, India has made remarkable progress in the health sector. However, a variety of eye-opening findings from the National Family Health Survey (NFHS) (Tamil nadu - NFHS-5) plainly show that healthcare access
                                remains a concern.</p>

                            <p>While rural India&#39;s health statistics remain dismal, the health status and access to health for the poor among urban slum dwellers has also been revealed to be appalling, with less than 4% of government primary healthcare
                                facilities.
                            </p>

                            <p></p>Urban slum people suffer from poor health for two main reasons: first, a lack of education and hence awareness; and second, a refusal to forego a day&#39;s income in order to reach the nearest medical facility. As a result,
                            the critical demand for healthcare for the poor is unmet.</p>
                            <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left; background: #fcac4b; padding: 30px 127px; max-width: 49%; color: #fff;">Aim</div>
                           <div class="col-lg-3" style="float: right; background: #5ad05e;padding: 30px 86px; max-width: 49%; color: #fff;">Beneficiary</div>
                        </div>
                        <div class="col-lg-12">
                           <div class="col-lg-3" style="float: left;background: #ff636c;padding: 30px 99px; margin-top: 5px; max-width: 50%; color: #fff;">Achievement</div>
                           <div class="col-lg-3" style="float: right; background: #1c62fe;padding: 30px 98px; margin-top: 5px; max-width: 49%; color: #fff;">Doner</div>
                        </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php')?>