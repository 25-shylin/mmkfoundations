<?php include('include/header.php')?>
        <!--=================================
=            Page Slider            =
==================================-->
        <div class="hero-slider">
            <!-- Slider Item -->
            <div class="slider-item slide1" style="background-image:url(images/slider/slider-bg-1.png)">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Slide Content Start -->
                            <div class="content style text-center">
                                <h2 class="text-white text-bold mb-2" data-animation-in="slideInLeft">Environmental Protection
                                </h2>
                                <p class="tag-text mb-4" data-animation-in="slideInRight"> <br> </p>
                                <a href="aboutus.html" class="btn btn-main btn-white" data-animation-in="slideInLeft" data-duration-in="1.2">Read More</a>
                            </div>
                            <!-- Slide Content End -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slider Item -->
            <div class="slider-item" style="background-image:url(images/slider/slider-bg-2.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Slide Content Start-->
                            <div class="content style text-center">
                                <h2 class="text-white" data-animation-in="slideInRight">We Care About Your Health</h2>
                                <p class="tag-text mb-4" data-animation-in="slideInRight" data-duration-in="0.6"> </p>
                                <a href="aboutus.html" class="btn btn-main btn-white" data-animation-in="slideInRight" data-duration-in="1.2">about us</a>
                            </div>
                            <!-- Slide Content End-->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slider Item -->
            <div class="slider-item" style="background-image:url(images/slider/slider-bg-3.jpg)">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Slide Content Start -->
                            <div class="content text-center style">
                                <h2 class="text-white text-bold mb-2" data-animation-in="slideInRight">Best Education Services</h2>
                                <p class="tag-text mb-4" data-animation-in="slideInLeft"></p>
                                <a href="education.html" class="btn btn-main btn-white" data-animation-in="slideInLeft" data-duration-in="1.2">Education</a>

                            </div>
                            <!-- Slide Content End -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="slider-item" style="background-image:url(images/slider/slider-bg-4.png)">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Slide Content Start -->
                            <div class="content text-center style">
                                <h2 class="text-white text-bold mb-2" data-animation-in="slideInRight">MMK Foundation</h2>
                                <p class="tag-text mb-4" data-animation-in="slideInLeft"></p>

                            </div>
                            <!-- Slide Content End -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="slider-item" style="background-image:url(images/slider/slider-bg-5.jpg)">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Slide Content Start -->
                            <div class="content text-center style">
                                <h2 class="text-white text-bold mb-2" data-animation-in="slideInRight">Old Age People</h2>
                                <p class="tag-text mb-4" data-animation-in="slideInLeft"></p>

                            </div>
                            <!-- Slide Content End -->
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!--====  End of Page Slider  ====-->

        <section class="cta">
            <div class="container">
                <div class="cta-block row no-gutters">
                    <div class="col-lg-4 col-md-6 emmergency item">
                        <i class="fa fa-phone"></i>
                        <h2>Emegency Cases</h2>
                        <a href="tel:1-800-700-6200">1-800-700-6200</a>
                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
                    </div>
                    <div class="col-lg-4 col-md-6 top-doctor item">
                        <i class="fa fa-stethoscope"></i>
                        <h2>24 Hour Service</h2>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore dignissimos officia dicta suscipit vel eum</p>
                        <a href="index-2.html" class="btn btn-main">Read more</a>
                    </div>
                    <div class="col-lg-4 col-md-12 working-time item">
                        <i class="fa fa-hourglass-o"></i>
                        <h2>Working Hours</h2>
                        <ul class="w-hours">
                            <li>Mon - Fri - <span>10:00am - 7:00pm</span></li>
                            <li>Mon - Fri - <span>10:00am - 7:00pm</span></li>
                            <li>Mon - Fri - <span>10:00am - 7:00pm</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!--about section-->
        <section class="feature-section section bg-gray">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="image-content">
                            <div class="section-title text-center">
                                <h3>Our <span>Work</span></h3>
                                <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam magni in at debitis <br> nam error officia vero tempora alias? Sunt?</p>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="item">
                                        <div class="icon-box">
                                            <figure>
                                                <a href="health.html"><img loading="lazy" src="images/resource/1.png" alt="features image"></a>
                                            </figure>
                                        </div>
                                        <h3 class="mb-2">Health</h3>
                                        <p>Since independence, India has made remarkable progress in the health sector. However, a variety of eye-opening findings from the National Family Health Survey (NFHS) (Tamil nadu - NFHS-5) plainly show that healthcare
                                            access remains a concern.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="item">
                                        <div class="icon-box">
                                            <figure>
                                                <a href="education.html">
                                                    <img loading="lazy" src="images/resource/2.png" alt="features image">
                                                </a>
                                            </figure>
                                        </div>
                                        <h3 class="mb-2">Education</h3>
                                        <p>Education is a state-level initiative of the MMK Foundation, a non-profit organisation dedicated to providing basic education and healthcare to impoverished children. The MMK Foundation, a non-profit organisation
                                            dedicated to improving the education </p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="item">
                                        <div class="icon-box">
                                            <figure>
                                                <a href="livelihood.html">
                                                    <img loading="lazy" src="images/resource/3.png" alt="features image">
                                                </a>
                                            </figure>
                                        </div>
                                        <h3 class="mb-2">Livelihood</h3>
                                        <p>Over one-third of India's population is under the age of 30, making up a significant portion of the country's labour force. According to Financial Express estimates, just 14% of new graduates graduating from colleges
                                            are employable, while the remainder are labelled unemployable.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="item">
                                        <div class="icon-box">
                                            <figure>
                                                <a href="disaster-response.html">
                                                    <img loading="lazy" src="images/resource/4.png" alt="features image">
                                                </a>
                                            </figure>
                                        </div>
                                        <h3 class="mb-2">Disaster Relief </h3>
                                        <p>Due to its geographical location, India is very vulnerable to numerous forms of natural calamities, making it a disaster-prone country. According to the National Disaster Management Authority of India, more than
                                            58.6% of the country's landmass is prone to earthquakes, </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End about section-->

        <!--Start about us area-->
        <section class="service-tab-section section">
            <div class="outer-box clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Nav tabs -->
                            <div class="tabs mb-5">
                                <ul class="nav nav-tabs justify-content-center" id="aboutTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" id="dormitory-tab" data-toggle="tab" href="#dormitory" role="tab" aria-controls="dormitory" aria-selected="true">Education</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="orthopedic-tab" data-toggle="tab" href="#orthopedic" role="tab" aria-controls="orthopedic" aria-selected="false">Health</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="sonogram-tab" data-toggle="tab" href="#sonogram" role="tab" aria-controls="sonogram" aria-selected="false">Livelihood</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="x-ray-tab" data-toggle="tab" href="#x-ray" role="tab" aria-controls="x-ray" aria-selected="false">Women Empowerment</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="diagnostic-tab" data-toggle="tab" href="#diagnostic" role="tab" aria-controls="diagnostic" aria-selected="false">Disaster Response</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="Protection-tab" data-toggle="tab" href="#Protection" role="tab" aria-controls="Protection" aria-selected="false">Environmental Protection</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="kid-tab" data-toggle="tab" href="#kid" role="tab" aria-controls="kid" aria-selected="false">Kid for Kid</a>
                                    </li>
                                </ul>
                            </div>
                            <!--Start single tab content-->
                            <div class="tab-content" id="aboutTab">
                                <div class="service-box tab-pane fade show active" id="dormitory">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/services/service-one.jpg" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Education</h3>
                                                </div>
                                                <div class="text">
                                                    <p>Education is a state-level initiative of the MMK Foundation, a non-profit organisation dedicated to providing basic education and healthcare to impoverished children. The MMK Foundation, a non-profit
                                                        organisation dedicated to improving the education of underprivileged children, thinks that there is no better place to begin than in the halls of education, whether the issue is healthcare, poverty,
                                                        population control, unemployment, or human rights.</p>
                                                    <p>Education is both the means and the end to a better life; it is the means because it allows an individual to earn a living, and it is the end because it increases one&#39;s awareness of a variety of
                                                        issues ranging from healthcare to appropriate social behaviour to understanding one&#39;s rights, allowing one to evolve as a better citizen. </p>
                                                </div>

                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End single tab content-->
                                <!--Start single tab content-->
                                <div class="service-box tab-pane fade" id="orthopedic">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/4.png" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Health</h3>
                                                </div>
                                                <div class="text">
                                                    <p>Since independence, India has made remarkable progress in the health sector. However, a variety of eye-opening findings from the National Family Health Survey (NFHS) (Tamil nadu - NFHS-5) plainly show
                                                        that healthcare access remains a concern.</p>
                                                    <p>While rural India&#39;s health statistics remain dismal, the health status and access to health for the poor among urban slum dwellers has also been revealed to be appalling, with less than 4% of government
                                                        primary healthcare facilities.
                                                    </p>
                                                    <p>Urban slum people suffer from poor health for two main reasons: first, a lack of education and hence awareness; and second, a refusal to forego a day&#39;s income in order to reach the nearest medical
                                                        facility. As a result, the critical demand for healthcare for the poor is unmet.</p>
                                                </div>

                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End single tab content-->
                                <!--Start single tab content-->
                                <div class="service-box tab-pane fade" id="sonogram">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/1.png" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Livelihood</h3>
                                                </div>
                                                <div class="text">
                                                    <p> Over one-third of India&#39;s population is under the age of 30, making up a significant portion of the country&#39;s labour force. According to Financial Express estimates, just 14% of new graduates
                                                        graduating from colleges are employable, while the remainder are labelled unemployable.
                                                    </p>

                                                    <p>This is not due to a lack of theoretical knowledge on their part. Instead, it&#39;s a lack of the necessary abilities and attitude. As a result, there is growing anxiety among the country&#39;s top businesses
                                                        about a shortage of ready-to-deliver staff. Furthermore, the macro perspective emphasises that it is critical for the underprivileged youth&#39;s energy to be channelled appropriately and in the
                                                        right direction to aid economic progress and nation building, avoiding their contribution to family problems, societal stress, and national sorrow.</p>

                                                    <P>This national-level initiative, through its livelihood programmes, teaches English proficiency, basic computer education, and soft skills to disadvantaged and underprivileged youngsters in order to improve
                                                        their career prospects in the fast-growing retail, hospitality, and BPO sectors.
                                                    </p>
                                                </div>

                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End single tab content-->
                                <!--Start single tab content-->
                                <div class="service-box tab-pane fade" id="x-ray">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/5.png" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Women Empowerment</h3>
                                                </div>
                                                <div class="text">
                                                    <p>Various research, as well as our own experience, have proven that working toward women&#39;s empowerment benefits the entire society. However, in India, far from empowering women, the majority are denied
                                                        even fundamental rights such as health, girls&#39; education for women&#39;s empowerment, job, and a decent social status.</p>
                                                    <p>According to a recent UNDP Human Development Report, India has a dangerously skewed sex ratio, with female infanticide and sex-selective abortions being the primary causes. </p>
                                                    <p>awareness of corporate innovations that accelerate women&#39;s empowerment and have a real impact on women&#39;s, families&#39;, and communities&#39; quality of life; child marriage is still practised
                                                        in many parts of India. This leads to early pregnancies, which endangers not only the lives and health of young women, but also their ability to raise a family. The MMK Foundation wants women and
                                                        girls to be able to make their own decisions and to understand that they do not object to being told who and when they should marry. We intend to put a stop to this type of discrimination by educating
                                                        individuals about family planning options.</p>
                                                </div>

                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End single tab content-->
                                <!--Start single tab content-->
                                <div class="service-box tab-pane fade" id="diagnostic">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/6.png" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Disaster Response</h3>
                                                </div>
                                                <div class="text">
                                                    <p> Due to its geographical location, India is very vulnerable to numerous forms of natural calamities, making it a disaster-prone country. According to the National Disaster Management Authority of India,
                                                        more than 58.6% of the country&#39;s landmass is prone to earthquakes, and over 12% is prone to floods; nearly 5,700km of the country&#39;s 7,516km long coastline is prone to cyclones and tsunamis;
                                                        and 68 percent of its cultivable area is prone to droughts, all of which highlight the importance of disaster preparedness.</p>


                                                    <p>Privileged children are made aware of the deprivation and pain endured by underprivileged children. KFK aims to instil a sense of conscience and a value system in children so that they grow up to be
                                                        responsible citizens and change agents. The KFK programme tries to make them count their blessings and understand the plight of those who are less fortunate before their minds are set with age. They
                                                        automatically turn their thoughts to positivity and develop the right outlook once they begin to recognise the value of the advantages they are born with. This eventually helps them develop into
                                                        not only successful but also responsible adults. They grow up to be significant change agents who positively contribute to society.</p>
                                                </div>


                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--End single tab content-->
                                <!--Start single tab content-->
                                <div class="service-box tab-pane fade" id="Protection">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/8.png" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Environmental Protection</h3>
                                                </div>
                                                <div class="text">
                                                    <p> We are a Trust of nature enthusiasts who want to safeguard and maintain the diversity of natural resources and a healthy environment by living in peace with nature. Participation, demonstration projects,
                                                        monitoring, and research, as well as cooperation and networking with other NGOs and government departments, all contribute to efforts for sustainable development.
                                                    </p>

                                                    <p>Maintain vigilant vigilance over nearby plant and animal habitats, air, water, and noise levels, among other things; protect natural resources, watersheds, and ecosystems, and push authorities to take
                                                        corrective action in cases of lapses or over-exploitation. Take steps to conserve ethnic culture and heritage, as well as to share expertise, knowledge, and information about all aspects of nature
                                                        and history with people who need it. Gather knowledge about environmentally friendly technologies and take steps to publicise them. Increase public awareness of the need to conserve water, fuel,
                                                        and other natural resources by promoting the use of renewable energy sources such as solar, wind, and biogas.</p>
                                                </div>


                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End single tab content-->

                                <!--End single tab content-->
                                <!--Start single tab content-->
                                <div class="service-box tab-pane fade" id="kid">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img loading="lazy" class="img-fluid" src="images/10.png" alt="service-image">
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contents">
                                                <div class="section-title">
                                                    <h3>Kid for Kid</h3>
                                                </div>
                                                <div class="text">
                                                    <p> Children are a country&#39;s future. They are the most effective change agents, whether in the family or in the community in which they live. It is therefore critical to assist children, to catch them
                                                        when they are young and to instil in them feelings of empathy and conscience so that they grow up to be responsible individuals. Recognizing this need, the MMK Foundation launched the Kid for Kid
                                                        (KFK) programme in 2022. Sensitization of privileged children and their parents to existing inequalities around them is a key goal of KFK.</p>
                                                    <p>Privileged children are made aware of the deprivation and pain endured by underprivileged children. KFK aims to instil a sense of conscience and a value system in children so that they grow up to be
                                                        responsible citizens and change agents. The KFK programme tries to make them count their blessings and understand the plight of those who are less fortunate before their minds are set with age. They
                                                        automatically turn their thoughts to positivity and develop the right outlook once they begin to recognise the value of the advantages they are born with. This eventually helps them develop into
                                                        not only successful but also responsible adults. They grow up to be significant change agents who positively contribute to society.</p>
                                                </div>


                                                <a href="index-2.html" class="btn btn-style-one">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End about us area-->

        <!--Service Section-->
        <section class="service-section bg-gray section">
            <div class="container">
                <div class="section-title text-center">
                    <h3>Our
                        <span>Events</span>
                    </h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Lorem ipsum dolor sit amet. qui suscipit atque <br> fugiat officia corporis rerum eaque neque totam animi, sapiente culpa. Architecto!</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="items-container">
                            <div class="item">
                                <div class="inner-box">
                                    <div class="img_holder">
                                        <a href="index-2.html">
                                            <img loading="lazy" src="images/gallery/1.jpg" alt="images" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="image-content text-center">
                                        <span>Our Foundation</span>
                                        <a href="index-2.html">
                                            <h6>MMK Events</h6>
                                        </a>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, vero.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="inner-box">
                                    <div class="img_holder">
                                        <a href="index-2.html">
                                            <img loading="lazy" src="images/gallery/2.jpg" alt="images" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="image-content text-center">
                                        <span>Our Foundation</span>
                                        <a href="index-2.html">
                                            <h6>MMK Events</h6>
                                        </a>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, vero.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="inner-box">
                                    <div class="img_holder">
                                        <a href="index-2.html">
                                            <img loading="lazy" src="images/gallery/3.jpg" alt="images" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="image-content text-center">
                                        <span>MMK Events</span>
                                        <a href="index-2.html">
                                            <h6>MMK Events</h6>
                                        </a>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, vero.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="inner-box">
                                    <div class="img_holder">
                                        <a href="service.html">
                                            <img loading="lazy" src="images/gallery/4.jpg" alt="images" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="image-content text-center">
                                        <span>Our Foundation</span>
                                        <a href="service.html">
                                            <h6>MMK Events</h6>
                                        </a>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, vero.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="inner-box">
                                    <div class="img_holder">
                                        <a href="service.html">
                                            <img loading="lazy" src="images/gallery/2.jpg" alt="images" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="image-content text-center">
                                        <span>Our Foundation</span>
                                        <a href="service.html">
                                            <h6>MMK Events</h6>
                                        </a>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, vero.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="inner-box">
                                    <div class="img_holder">
                                        <a href="service.html">
                                            <img loading="lazy" src="images/gallery/3.jpg" alt="images" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="image-content text-center">
                                        <span>MMK Events</span>
                                        <a href="service.html">
                                            <h6>MMK Events</h6>
                                        </a>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, vero.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Service Section-->

        <!--team section-->
        <!-- <section class="team-section section">
            <div class="container">
                <div class="section-title text-center">
                    <h3>Our Expert
                        <span>Doctors</span>
                    </h3>
                    <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem illo, rerum
                        <br>natus nobis deleniti doloremque minima odit voluptatibus ipsam animi?</p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="team-member">
                            <img loading="lazy" src="images/team/doctor-2.jpg" alt="doctor" class="img-fluid">
                            <div class="contents text-center">
                                <h4>Dr. Robert Barrethion</h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, aspernatur.</p>
                                <a href="appointment.html" class="btn btn-main">Book Appointment</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="team-member">
                            <img loading="lazy" src="images/team/doctor-lab-3.jpg" alt="doctor" class="img-fluid">
                            <div class="contents text-center">
                                <h4>Dr. Marry Lou</h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, aspernatur.</p>
                                <a href="appointment.html" class="btn btn-main">Book Appointment</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="team-member">
                            <img loading="lazy" src="images/team/event-2.jpg" alt="doctor" class="img-fluid">
                            <div class="contents text-center">
                                <h4>Dr. Sansa Stark</h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, aspernatur.</p>
                                <a href="appointment.html" class="btn btn-main">Book Appointment</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!--End team section-->

        <!--testimonial-section-->
        <section class="testimonial-section" style="background: url(images/testimonials/1.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h3>Testimonial
                                <span></span>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="testimonial-carousel">
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/1.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>Adam Rose</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/2.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>David Warner</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/3.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>Amy Adams</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/1.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>Adam Rose</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/2.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>David Warner</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/3.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>Amy Adams</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/1.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>Adam Rose</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/2.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>David Warner</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                            <!--Slide Item-->
                            <div class="slide-item">
                                <div class="inner-box text-center">
                                    <div class="image-box">
                                        <figure>
                                            <img loading="lazy" src="images/testimonials/3.png" alt="">
                                        </figure>
                                    </div>
                                    <h6>Amy Adams</h6>
                                    <p class="mb-0">Neque porro quisquam est, qui dolorem ipsum quia consectetur, dolor sit amet, consectetur, numquam Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, at?</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End testimonial-section-->

        <!-- Contact Section -->
        <section class="appoinment-section section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="accordion-section">
                            <div class="section-title">
                                <h3>FAQ</h3>
                            </div>
                            <div class="accordion-holder">
                                <div class="accordion" id="accordionGroup" role="tablist" aria-multiselectable="true">
                                    <div class="card">
                                        <div class="card-header" role="tab" id="headingOne">
                                            <h4 class="card-title">
                                                <a role="button" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                Why Should I choose Education
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordionGroup">
                                            <div class="card-body">
                                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
                                                on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings
                                                occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" role="tab" id="headingTwo">
                                            <h4 class="card-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                    Why Should I choose Medical Health
            </a>
                                            </h4>
                                        </div>
                                        <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordionGroup">
                                            <div class="card-body">
                                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
                                                on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings
                                                occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" role="tab" id="headingThree">
                                            <h4 class="card-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
              How many visitors are allowed?
            </a>
                                            </h4>
                                        </div>
                                        <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionGroup">
                                            <div class="card-body">
                                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
                                                on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings
                                                occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="contact-area pl-0 pl-lg-5">
                            <div class="section-title">
                                <h3>Request
                                    <span>Appointment</span>
                                </h3>
                            </div>
                            <form name="contact_form" class="default-form contact-form" action="http://www.sreechakragroup.com/!#" method="post">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input class="form-control" type="text" name="Name" placeholder="Name" required="">
                                        </div>
                                        <div class="form-group">
                                            <input class="form-control" type="email" name="Email" placeholder="Email" required="">
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control" name="subject">
                                                    <option>Health</option>
                                                    <option>Education</option>
                                                    <option>Child</option>
                                                    <option>Old Age</option>
                                                </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input class="form-control" type="text" name="Phone" placeholder="Phone" required="">
                                        </div>
                                        <div class="form-group">
                                            <input class="form-control" type="text" name="Date" placeholder="Date" required="" id="datepicker" autocomplete="off">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control" name="subject">
                                                    <option>Organization</option>
                                                    <option>Department</option>
                                                    <option>Foundation</option>
                                                </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <textarea class="form-control" name="form_message" placeholder="Your Message" required=""></textarea>
                                        </div>
                                        <div class="form-group text-center">
                                            <button type="submit" class="btn-style-one">submit now</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Section -->
<?php include('include/footer.php') ?>
       